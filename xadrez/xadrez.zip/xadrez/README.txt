A Pen created at CodePen.io. You can find this one at https://codepen.io/omarjadalla/pen/EykIs.

 Jogo de xadrez desenvolvido em Javascript, CSS e HTML.