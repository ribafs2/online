## About

[This](https://webdevtrick.com/demos/svg-analog-clock/) svg/js/html clock repacked for yad

    yad --version
    5.0 (GTK+ 3.24.5)
    
## Run

    ./openwithyad
    
## Scrot

![](scrot.png)
