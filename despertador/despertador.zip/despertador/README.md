# alarm-clock-js
its simple alarm clock
<h3><li>html</li>
<li>css</li>
<li>javascript</li>
 </h3> 
