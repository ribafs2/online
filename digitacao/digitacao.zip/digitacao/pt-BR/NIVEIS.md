# Adicionar níveis

- inglês
- português
- minúsculas
- minúsculas com inicial maiúsculas

