# Teste de Digitação

Este é um fork do projeto Typing Speed Test

A Web Application to test and practice your typing speed. 

Gostei muito do projeto, pois além de bonito tem muitos recursos interessantes do JavaScript. Então fiz uma pequena tradução e algumas adaptações.

Para conferir online, veja:

https://ribamar.net.br/digitacao-teste

## Licence
MIT
