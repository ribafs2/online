# Typing Speed Test

I have developed this typing speed tester using HTML5, CSS, DOM and Javascript. The tester displays 40 words at a time according to the difficulty chosen by the user.

![image](https://user-images.githubusercontent.com/42926487/114231567-3d73a580-9998-11eb-9636-732c05e1cd06.png)


link to website -> https://shreyagarwal13.github.io/typing-speed-test/
